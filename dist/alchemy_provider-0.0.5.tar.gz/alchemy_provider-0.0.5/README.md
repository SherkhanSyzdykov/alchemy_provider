Dynamic query build based on SQLAlchemy Core and ORM
